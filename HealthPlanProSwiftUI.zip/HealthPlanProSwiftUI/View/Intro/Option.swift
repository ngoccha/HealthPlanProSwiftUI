//
//  Option.swift
//  HealthPlanProSwiftUI
//
//  Created by iKame Elite Fresher 2025 on 7/21/25.
//

import Foundation

struct Option {
    var name: String
    var imageName: String
    var isSelected: Bool
}

